

class Position:

    def __init__(self, row, col, x, y):

        self.row = row
        self.col = col

        self.x = x
        self.y = y