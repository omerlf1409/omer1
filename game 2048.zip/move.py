import game


class move:

    def __init__(self, is_up, is_down, is_left, is_right):
        self.value =


