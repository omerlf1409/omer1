import pygame

window_width = 800
window_height = 700

"colors"

white = (255, 255, 255)
black = (51, 51, 51)
color_2 = (235, 235, 235)
color_4 = (217, 211, 173)
color_8 = (255, 176, 79)
color_16 = (240, 100, 58)
color_32 = (222, 75, 55)
color_64 = (255, 60, 0)
color_128 = (250, 241, 122)
color_256 = (250, 239, 87)
color_512 = (219, 208, 55)
color_1024 = (224, 218, 34)
color_2048 = (248, 252, 5)

win_number = 2048

board_size = 4

move_up = 1
move_down = 2
move_right = 3
move_left = 4

empty_cell = 0

full_range = range(board_size)
